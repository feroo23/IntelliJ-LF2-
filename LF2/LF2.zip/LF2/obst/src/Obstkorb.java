import java.util;

/*public class Obstkorb {

    private ArrayList<Obst> korb = new ArrayList<Obst>();

    /**
     * Fügt dem Obstkorb ein Stück hinzu.
     * @param obst Das Hinzuzufügede stück Obst.
     */
/*  public void fuegeHinzu(Obst obst){
        korb.add(obst);
    }

    /**
     * nimmt ein stück Obst aus dem Korb heraus, wenn es vorhanden ist.
     * @param obst Das gewünchte Stück Obsr
     * @return Das Gewünschte Stück Obbst oder null, Wenn es nicht vorhanden ist.
     */
 /*   public Obst nehmeHerasu(Obst obst) {
        if (korb.contains(obst)) {
            korb.remove(obst);
            return obst;
        }
        else {
            return null;
        }
    }*\
}
