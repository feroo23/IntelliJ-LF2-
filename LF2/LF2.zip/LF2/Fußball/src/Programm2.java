public class Programm2 {
    public static void main(String[] args) {

        Torwart torwart = new Torwart("Torwart", 23,2,8,7);

        System.out.println("\nTorwart");
        System.out.println(torwart.toString());
    }

}
