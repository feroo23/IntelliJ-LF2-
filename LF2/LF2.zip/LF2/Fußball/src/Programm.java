public class Programm {
    public static void main(String[] args) {

        Spieler spieler = new Spieler("kylian Mbappe", 22, 9, 134, 8, 94);
        Trainer trainer = new Trainer("Mauricio Pochettino ", 48, 8);

        System.out.println("\nSpieler");
        System.out.println(spieler.toString());
        System.out.println();
        System.out.println("\nTrainer");
        System.out.println(trainer.toString());
    }
}
